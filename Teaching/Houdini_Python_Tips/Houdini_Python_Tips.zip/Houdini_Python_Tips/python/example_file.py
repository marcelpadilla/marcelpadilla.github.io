print("Executing code from the file in $HIP/python/example_file.py:") 
